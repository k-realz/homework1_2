//
//  ViewController.swift
//  Netology_IB_Instruments
//
//  Created by Kirill Komov on 20.06.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

