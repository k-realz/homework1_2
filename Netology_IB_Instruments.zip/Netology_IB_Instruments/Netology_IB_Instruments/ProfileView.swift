//
//  ProfileView.swift
//  Netology_IB_Instruments
//
//  Created by Kirill Komov on 20.06.2021.
//

import UIKit

class ProfileView: UIView {

    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userDateBirthLabel: UILabel!
    @IBOutlet weak var userCityLabel: UILabel!
    @IBOutlet weak var userAvatarImage: UIImageView!
    @IBOutlet weak var userTextView: UITextView!
    


}
